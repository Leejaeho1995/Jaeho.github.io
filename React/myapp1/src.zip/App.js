import React , {useState } from 'react';
import Home from './layout/Home';
import styles from './index.css'
// const addCount =()=>{
//   setCount(count + 1)
//   console.log(count)

function App() {
return(
  <div>
    <Home/>
  </div>
)
  }
export default App;

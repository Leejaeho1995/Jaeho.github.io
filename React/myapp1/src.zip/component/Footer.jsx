import React from 'react'

const Footer = () => {
  const styles ={
    backgroundColor:"#666",
    color:"#fff",
    fontSize:"30px",
    textAlign:"center"
  }
  return (
    <div style={styles}>Footer</div>
  )
}

export default Footer
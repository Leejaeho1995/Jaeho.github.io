import React from 'react'

const Main = ({color, txt, name}) => {
  return (
    <>
    <div id="Myreturn" className="title"
    style={{backgroundColor:color}}>
        WE ARE
        <div>
            Brand Promotion
        </div>
    
    </div>

</>
  )
}

export default Main
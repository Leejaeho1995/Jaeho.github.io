$(document).on("pagecreate",function(){
    $.ajax({
        type:"get",
        url:"./js/list.json",
        dataType:"json",
        success:function(data){
            console.log(data)
            data.forEach((list,i)=>{
                $(".list").append(`<a href="home.html?foodid=${list.foodId}" class="row food-card">
                <div class="col-4 my-auto">
                   <img src="${list.foodImg}" 
                        class="img-fluid" alt="${list.foodTitle}" />
                </div>
                <div class="col-7">
                   <h1 class="food-title">
                   ${list.foodTitle}

                       칠리새우를 넣은 진짜 맛좋은 더블버거
                   </h1>
                   <p class="food-description">
                   ${list.foodDescription}
                       지금 막 출시한 새로운 신상품
                   </p>
                   <div class="food-ratings">
                   ${list.foodStar}
                       <i class="ri-star-fill"></i>
                       <i class="ri-star-fill"></i>
                       <i class="ri-star-fill"></i>
                       <i class="ri-star-half-line"></i>
                       <i class="ri-star-line"></i>
                   </div>
                   <p class="food-price">
                   ${list.foodPrice}
                       150,000원
                   </p>
                </div>
                <div class="col-1">
                   <p class="food-wish">
                       <i class="ri-heart-fill"></i>
                   </p>
                </div>
              </a>`)
            })
        },
        error: function(){
            console.log("에러")
        }
    })

})
import React from 'react'
import Home from './layout/Home'

const App = () => {
  return (<Home />)
}

export default App
import React from 'react'

const SecA = () => {
  return (
    <div>SecA</div>
  )
}

export default SecA
import React from 'react'

const SecB = () => {
  return (
    <div>SecB</div>
  )
}

export default SecB
import React from 'react'

const SecC = () => {
  return (
    <div>SecC</div>
  )
}

export default SecC
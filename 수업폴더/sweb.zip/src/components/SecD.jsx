import React from 'react'

const SecD = () => {
  return (
    <div>SecD</div>
  )
}

export default SecD
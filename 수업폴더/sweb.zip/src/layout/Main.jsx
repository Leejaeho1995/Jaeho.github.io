import React from 'react'
import SecA from '../components/SecA'
import SecB from '../components/SecB'
import SecC from '../components/SecC'
import SecD from '../components/SecD'

const Main = () => {
  return (
    <div>
       <SecA />
       <SecB />
       <SecC />
       <SecD />
    </div>
  )
}

export default Main